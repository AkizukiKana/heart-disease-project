
#A skeleton for implementing Naive Bayes Classifier in Python.
## Author: Md Faisal Kabir

import numpy as np
import pandas as pd
import random
import time
import copy
from featureClasses import *
from sklearn.model_selection import train_test_split

#Function Junction
def findFeatureDomains(training_data, rows, cols,):
    """If a feature has more than 5 different values
       then that feature is declared continuous, otherwise
       the feature is discrete"""
    feature_domains = []
    count = 0
    temp = []
    for i in range(cols):
        for j in range(rows):
            if Xtrain[j,i] not in temp:
                temp.append(Xtrain[j,i])
                count += 1
            if count > 5:
                feature_domains.append('c')
                break # out of inner for loop
        if count < 5:
            feature_domains.append('d')
        count = 0
        temp.clear()
    return feature_domains

def findClassificationLabels(training_data, rows, final_column):
    """This function finds and returns all the different labels
       of the output data"""
    labels = []
    for i in range(rows):
        if training_data[i, final_column] not in labels:
            labels.append(training_data[i, final_column])
    return labels


#All of the discrete probabilites are kept in "frequency count form" until each
#probability needs to be calculated
def findClassificationCounts(training_data, rows, final_column, classifications):
    """This function finds and returns all the counts for each
       classification label"""
    classificationCounts = {}
    #initialize the dictionary with each classifications as a key with a count of zero
    for i in classifications:
        classificationCounts.update({i:0})
    for i in range(rows):
        item = training_data[i,final_column]
        classificationCounts.update({item:classificationCounts[item] + 1})
    #Now the dictionary has the total count of each classification
    return classificationCounts



data = pd.read_csv('heart_women.csv')
#data.drop("sex", inplace=True, axis=1)
#print(data)
nbc = []
#Begin loop
for trial in range(40):
    arr = np.array(data)



    np.random.shuffle(arr)

    trainingSplit = int(arr.shape[0] * 0.7)
    Xtrain = arr[: trainingSplit]
    Xtest = arr[trainingSplit:]

    number_of_samples = Xtrain.shape[0]
    number_of_features = Xtrain.shape[1]-1


    #Check if each feature is continuous or discrete

    feature_domains = findFeatureDomains(Xtrain,number_of_samples,number_of_features)
    #print("feature_domains {}".format(feature_domains))

    #Find how many different classifications there are
    final_column = number_of_features
    classificationLabels = findClassificationLabels(Xtrain, number_of_samples,final_column)
    #print("classificationLabels {}".format(classificationLabels))

    #Find the count of each classification
    classificationCounts = findClassificationCounts(Xtrain, number_of_samples, final_column, classificationLabels)
    #print("classificationCounts {}".format(classificationCounts))

    temp_class = None
    classifications = []
    for label in classificationLabels:
        #print("label {}".format(label))
        #input()
        temp_class = copy.deepcopy(Classification(name = label, count = classificationCounts[label]))
        #print(temp_class)
        #input()
        #Now fill out classification with correct data
        for feature in range(len(feature_domains)):
            #print("feature {}".format(feature))
            #input()
            #Process continuous features
            if feature_domains[feature] == 'c':

                con_feature = copy.deepcopy(ContinuousFeature(attribute_col = feature))
                temp = []
                for row in range(number_of_samples):
                    if Xtrain[row,final_column] == temp_class.name:

                        temp.append(Xtrain[row,feature])
               # print(temp)
               # input()
               # print("Mean: {}".format(mean(temp)))
               # input()
               # print("Variance: {}".format(variance(temp)))
               # input()
                con_feature.mean = mean(temp)
                con_feature.variance = variance(temp)
                #Add feature to classification
                temp_class.features.append(copy.deepcopy(con_feature))
                temp.clear()
                con_feature = None
            elif feature_domains[feature] == 'd':
                dis_feature = copy.deepcopy(DiscreteFeature(attribute_col = feature, given_count = temp_class.count))
                #First, we must add each value as a category into the dictionary
                dictValues = []
                for row in range(number_of_samples):
                    if Xtrain[row,feature] not in dictValues:
                        dis_feature.valuePairs.update({Xtrain[row,feature]:0})

                #print(dis_feature)
                #print(dis_feature.valuePairs.keys())
                #input()
                dictValues.clear()
                for row in range(number_of_samples):
                    if Xtrain[row,final_column] == temp_class.name:
                        dis_feature.valuePairs.update({Xtrain[row,feature]:dis_feature.valuePairs[Xtrain[row,feature]]+1})
                temp_class.features.append(copy.deepcopy(dis_feature))
        classifications.append(copy.deepcopy(temp_class))
        #del temp_class # Maybe this work... because I don't understand python...





    number_of_tests = Xtest.shape[0] # Number of points in the testing data.
    number_of_features = Xtest.shape[1] - 1

    tp = 0 #True Positive
    fp = 0 #False Positive
    tn = 0 #True Negative
    fn = 0 #False Negative

    sample = []
    probabilities = {}
    for row in range(number_of_tests):
        for col in range(number_of_features):
            sample.append(Xtest[row,col])
        for i in classifications:
            #prob = i.get_prob(sample, number_of_samples)
            #print(prob)
            #input()
            probabilities.update({i.name : i.get_prob(sample, number_of_samples)})

        prediction = max(probabilities, key = probabilities.get)
        actual = Xtest[row,final_column]
        #print("Prediction: {}, Actual: {}\n".format(prediction, Xtest[row, final_column]))
        if prediction == actual:
            if actual == 1:
                tp += 1
            else:
                tn += 1
        elif prediction != actual:
            if actual == 1:
                fn += 1
            else:
                fp += 1
        sample.clear()
        probabilities.clear()

    #output accuracy
    nbc.append((tp + tn)/number_of_tests)
# End Loop

def output(arr, namestr):
    val = 0
    for i in arr:
        val += i

    val = val / len(arr)
    print("{} average testing accuracy: {:.3f}".format(namestr, val))

#end def

output(nbc, "Naive Bayes Classifier")
