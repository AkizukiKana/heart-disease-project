import numpy as np
import pandas as pd
from sklearn.model_selection import train_test_split
from sklearn.neighbors import KNeighborsClassifier
from sklearn.linear_model import LogisticRegression
from sklearn.tree import DecisionTreeClassifier
from sklearn.ensemble import RandomForestClassifier
from sklearn.pipeline import make_pipeline
from sklearn.preprocessing import StandardScaler
from sklearn.metrics import confusion_matrix
import itertools
import matplotlib.pyplot as plt


#use this to change files quickly

file_iter = 3

files = ["data/heart.csv",
         "data/heart_men.csv",
         "data/heart_women.csv",
         "data/cleveland_heart.csv",
         "data/cleveland_heart_men.csv",
         "data/cleveland_heart_women.csv"]

data = pd.read_csv(files[file_iter])
#Drop columns here
#data.drop('oldpeak', inplace=True, axis=1)
#data.drop('exang', inplace=True, axis=1)
#data.drop('thalach', inplace=True, axis=1)
#data.drop('cp', inplace=True, axis=1)
#data.drop('sex', inplace=True, axis=1)
#
print(data)

arr = np.array(data)

print("Shape of arr: {}".format(arr.shape))

column_labels = data.columns

KNN = []
LogReg = []
DecisionTree = []
RandomForest = []

#Begin testing loop
for i in range(80):
    np.random.shuffle(arr)

    samples = arr[:, :-1]
    labels = arr[:, -1]
    x_train, x_test, y_train, y_test = train_test_split(samples, labels, test_size = 0.30)

    #neigh = KNeighborsClassifier(n_neighbors=4)
    #neigh.fit(x_train, y_train)
    pipe = make_pipeline(StandardScaler(), KNeighborsClassifier(n_neighbors=4))
    pipe.fit(x_train,y_train)
    KNN.append(pipe.score(x_test,y_test))
    
    #logreg = LogisticRegression(C=1, max_iter = 1000).fit(x_train, y_train)
    pipe = make_pipeline(StandardScaler(), LogisticRegression(C=1, max_iter = 1000))
    pipe.fit(x_train, y_train)
    LogReg.append(pipe.score(x_test, y_test))

    #Forget about this one
    #logreg100 = LogisticRegression(C=100,max_iter = 1000).fit(x_train, y_train)
    #LogRegwReg.append(logreg100.score(x_test, y_test))

    tree = DecisionTreeClassifier(max_depth=3, random_state=0)
    tree.fit(x_train,y_train)
    DecisionTree.append(tree.score(x_test,y_test))

    forest = RandomForestClassifier(n_estimators=100,random_state=1)
    forest.fit(x_train,y_train)
    RandomForest.append(forest.score(x_test,y_test))

#End Loop
def mean(arr):
    #calculate mean
    val = 0
    for i in arr:
        val += i

    mean = val / len(arr)
    return mean

def std(arr):    
    mu = mean(arr)    
    #calculate standard deviation
    val = 0
    for i in arr:
        val += (i - mu)**2
        
    std = (val/float((len(arr) - 1)))**0.5    
    return std

#end def

#save results to 
f = open("analysis/temp_results.csv", "a")

meanString = ""
stdString = ""
datalabel = "cl_heart"

meanString = "\n{},{},{:.3f},{:.3f},{:.3f},{:.3f}".format(datalabel,
                                                                 "mean",
                                                                 mean(KNN),
                                                                 mean(LogReg),
                                                                 mean(DecisionTree),
                                                                 mean(RandomForest))

stdString = "\n{},{},{:.3f},{:.3f},{:.3f},{:.3f}".format(datalabel,
                                                                "std",
                                                                std(KNN),
                                                                std(LogReg),
                                                                std(DecisionTree),
                                                                std(RandomForest))
#
#crap = input("Stopping here to prevent accidental file writing")
#exit()
f.write(meanString)
f.write(stdString)
f.close()
#KNN = []
#LogReg = []
#DecisionTree = []
#RandomForest = []
