import numpy as np
import pandas as pd
from sklearn.model_selection import train_test_split
from sklearn.neighbors import KNeighborsClassifier
from sklearn.linear_model import LogisticRegression
from sklearn.tree import DecisionTreeClassifier
from sklearn.ensemble import RandomForestClassifier
from sklearn.metrics import confusion_matrix
import itertools
import matplotlib.pyplot as plt

def plot_confusion_matrix(cm, classes,
                        normalize=False,
                        title='Confusion matrix',
                        cmap=plt.cm.Blues):
    """
    This function prints and plots the confusion matrix.
    Normalization can be applied by setting `normalize=True`.
    """
    plt.imshow(cm, interpolation='nearest', cmap=cmap)
    plt.title(title)
    plt.colorbar()
    tick_marks = np.arange(len(classes))
    plt.xticks(tick_marks, classes, rotation=45)
    plt.yticks(tick_marks, classes)

    if normalize:
        cm = cm.astype('float') / cm.sum(axis=1)[:, np.newaxis]
        print("Normalized confusion matrix")
    else:
        print('Confusion matrix, without normalization')

    print(cm)

    thresh = cm.max() / 2.
    for i, j in itertools.product(range(cm.shape[0]), range(cm.shape[1])):
        plt.text(j, i, cm[i, j],
            horizontalalignment="center",
            color="white" if cm[i, j] > thresh else "black")

    plt.tight_layout()
    plt.ylabel('True label')
    plt.xlabel('Predicted label')
    plt.show()

data = pd.read_csv('heart_men.csv')
#data.drop('sex', inplace=True, axis=1)
#Drop columns here
#data.drop('oldpeak', inplace=True, axis=1)
#data.drop('exang', inplace=True, axis=1)
#data.drop('thalach', inplace=True, axis=1)
#data.drop('cp', inplace=True, axis=1)

#
print(data)

arr = np.array(data)

print("Shape of arr: {}".format(arr.shape))

column_labels = data.columns

KNN = []
LogReg = []
LogRegwReg = []
DecisionTree = []
RandomForest = []

#Begin testing loop
for i in range(40):
    np.random.shuffle(arr)

    samples = arr[:, :-1]
    labels = arr[:, -1]
    x_train, x_test, y_train, y_test = train_test_split(samples, labels, test_size = 0.30)

    neigh = KNeighborsClassifier(n_neighbors=4)
    neigh.fit(x_train, y_train)
    KNN.append(neigh.score(x_test,y_test))
    
    logreg = LogisticRegression(C=10, max_iter = 1000).fit(x_train, y_train)
    LogReg.append(logreg.score(x_test, y_test))

    logreg100 = LogisticRegression(C=100,max_iter = 1000).fit(x_train, y_train)
    LogRegwReg.append(logreg100.score(x_test, y_test))

    tree = DecisionTreeClassifier(max_depth=3, random_state=0)
    tree.fit(x_train,y_train)
    DecisionTree.append(tree.score(x_test,y_test))

    forest = RandomForestClassifier(n_estimators=100,random_state=1)
    forest.fit(x_train,y_train)
    RandomForest.append(forest.score(x_test,y_test))

#End Loop
def output(arr, namestr):
    val = 0
    for i in arr:
        val += i

    val = val / len(arr)
    print("{} average testing accuracy: {:.3f}".format(namestr, val))

#end def

output(KNN,"KNN")
output(LogReg,"LogReg")
output(LogRegwReg, "LogRegwReg")
output(DecisionTree, "DecisionTree")
output(RandomForest, "RandomForest")
