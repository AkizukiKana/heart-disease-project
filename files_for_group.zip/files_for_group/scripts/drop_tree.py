import numpy as np
import pandas as pd

data1 = pd.read_csv("analysis/all_features.csv")
print(data1)
data2 = pd.read_csv("analysis/fewer_features.csv")
print(data2)

data1.drop('DecisionTree', inplace=True, axis=1)
data2.drop('DecisionTree', inplace=True, axis=1)

data1.to_csv("analysis/all_features_final.csv", index=False)
data2.to_csv("analysis/fewer_features_final.csv", index=False)
