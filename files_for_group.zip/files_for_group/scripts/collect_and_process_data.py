import numpy as np
import pandas as pd
import csv
db1 = pd.read_csv("processed.hungarian.csv")

print(db1)

db1.drop("slope", inplace=True, axis=1)
db1.drop("ca", inplace=True, axis=1)
db1.drop("thal", inplace=True, axis=1)

print(db1)

db1 = db1.replace({'?': np.nan}).dropna().astype(float)

print(db1)

#db1.to_csv("data/hungarian.csv")
db1 = np.array(db1)

print(db1)
output = []

for i in range(db1.shape[0]):
    if db1[i][-1] == 0:
        output.append(db1[i])
    elif( db1[i][-1] == 1 or
          db1[i][-1] == 2 or
          db1[i][-1] == 3 or
          db1[i][-1] == 4):
        db1[i][-1] = 1
        output.append(db1[i])


with open("hungarian.csv","w+") as my_csv:
    csvWriter = csv.writer(my_csv,delimiter=',')
    csvWriter.writerows(output)
