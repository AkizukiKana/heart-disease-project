"""Classes for features used in Naive Bayes Classifier along with
   related functions"""
import math
from scipy import stats
def mean(vec):
    agg = 0
    for i in vec:
        agg = agg + i
    return agg / len(vec)

def variance(vec):
    mu = mean(vec)
    agg = 0
    for i in vec:
        agg = agg + (i - mu)**2
    return (agg/(len(vec) - 1))

def norm_pdf(x, mu, sigma_sq):
    return 1/((2*math.pi*sigma_sq)**0.5)*math.exp((-1*(x - mu)**2)/(2*sigma_sq))

class Feature:
    def __init__(self, attribute_col):
        self.attribute_col = attribute_col
        
class DiscreteFeature(Feature):
    def __init__(self, attribute_col, given_count,valuePairs = {}):
        super().__init__(attribute_col)
        self.valuePairs = valuePairs
        self.given_count = given_count
        
    def get_prob(self,valueKey):
        try:
            result = self.valuePairs[valueKey] / self.given_count
            if result == 0:
                return 1 / self.given_count # For lack of better Laplacian Correction
            else:
                return result
        except KeyError:
            #print("KeyError: {} is not a key in this feature\n".format(valueKey))
            return 1/ self.given_count

    def get_description(self):
        output = "---DISCRETE_FEATURE OBJECT---\n"
        output += "Given_count: {}\n".format(self.given_count)
        for key in self.valuePairs.keys():
            output += "Key: {} Value: {}\n".format(key, self.valuePairs[key])
        return output
    
class ContinuousFeature(Feature):
    def __init__(self, attribute_col, mean = 0, variance = 1):
        super().__init__(attribute_col)
        self.mean = mean
        self.variance = variance     
        
    def get_prob(self, sample_data):     
        data_high = sample_data * 1.3
        data_low = sample_data * 0.7
        result = norm_pdf(sample_data, self.mean, self.variance)
        return result
    
    def get_description(self):
        output = "---CONTINUOUS_FEATURE OBJECT---\n"
        output += "Mean:     {}\n".format(self.mean)
        output += "Variance: {}\n".format(self.variance)
        return output
    
class Classification:
    def __init__(self, name, count, features = []):
        self.name = name
        self.count = count
        self.features = features

    def get_description(self):
        output = "-------CLASSIFICATION OBJECT---------\n"
        output += "Classification name: {}\n".format(self.name)
        output += "Classification count: {}\n".format(self.count)
        output += "Number of features {}\n".format(len(self.features))
        for feature in range(len(self.features)):
            output += "Feature {}\n".format(feature)
            output += self.features[feature].get_description()
        return output
    
    def get_prob(self, sample, number_of_samples):
        probability = self.count / number_of_samples
        for i in range(len(self.features)):
            probability *= self.features[i].get_prob(sample[i])
        return probability

    def display_prob(self, sample, number_of_samples):
        hashTable = {}
        classificationProb = self.count / number_of_samples
        hashTable.update({"Classification Prob": classificationProb})
        for i in range(len(self.features)):
            hashTable.update({"Feature " + str(i):self.features[i].get_prob(sample[i])})
        print("Classification Name: " + str(self.name))
        for i in hashTable:
            print(str(i) + " : " + str(hashTable[i]))                    
