import numpy as np
import pandas as pd
import csv

data = pd.read_csv('data/collection.csv')
print(data)

arr = np.array(data)

print("Shape of arr: {}".format(arr.shape))

men = []
women = []

for i in range(arr.shape[0]):
    if arr[i][1] == 0:
        women.append(arr[i])
    elif arr[i][1] == 1:
        men.append(arr[i])




with open("data/heart_men.csv","w+") as my_csv:
    csvWriter = csv.writer(my_csv,delimiter=',')
    csvWriter.writerows(men)

with open("data/heart_women.csv","w+") as my_csv:
    csvWriter = csv.writer(my_csv,delimiter=',')
    csvWriter.writerows(women)
