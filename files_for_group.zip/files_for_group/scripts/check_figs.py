import csv
def output(arr, namestr):
    #calculate mean
    val = 0
    for i in arr:
        val += i

    mean = val / len(arr)
    #calculate standard deviation
    val = 0
    for i in arr:
        val += (i - mean)**2
        print("val: {}".format(val))
    std = (val/(len(arr) - 1))**0.5
    print("val: {}".format(val))
    print("{} mean testing accuracy: {:.3f}".format(namestr, mean))
    print("{} s.d. testing accurarcy: {:.3f}".format(namestr, std))

#end def

temp = []

with open("data/temp.csv","r") as my_csv:
    csvReader = csv.reader(my_csv,delimiter=',')
    for i in csvReader:
        temp.append(float(i[0]))
#
output(temp,'temp')
