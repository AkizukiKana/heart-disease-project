import numpy as np
import pandas as pd

data = pd.read_csv("analysis/final_results.csv")

print(data)
