import numpy as np
import pandas as pd

data1 = pd.read_csv("analysis/temp_results_cleveland_fewer_features.csv")
print(data1)
data2 = pd.read_csv("analysis/temp_nbc_results_fewer_features.csv")
print(data2)


data2.drop('datalabel', inplace=True, axis=1)
data2.drop('metric', inplace=True, axis=1)

data1 = data1.reset_index(drop=True)
data2 = data2.reset_index(drop=True)

data_final = data1.join(data2)

print(data_final)

data_final.to_csv("analysis/combined_table.csv", index=False)
